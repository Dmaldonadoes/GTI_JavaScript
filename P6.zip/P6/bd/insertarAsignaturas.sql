-- insertarAsignaturas.sql
insert into Asignatura values ("Programacion", "00"); 
insert into Asignatura values ("Matematicas", "01");
insert into Asignatura values ("Fisica", "02");
