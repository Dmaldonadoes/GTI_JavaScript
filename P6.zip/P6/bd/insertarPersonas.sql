-- insertarPersonas.sql
insert into Persona values ("20123456A", "Juan", "Farola"); 
insert into Persona values ("20123457B", "Maria", "Garcia"); 
insert into Persona values ("20123458C", "Jose", "Perez"); 
insert into Persona values ("20123459D", "Jose", "Ramirez");
insert into Persona values ("54024103R", "Diego", "Maldonado");