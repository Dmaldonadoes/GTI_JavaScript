-- insertarMatricula.sql
insert into Matricula values ("20123456A", "00");
insert into Matricula values ("20123456A", "01");
insert into Matricula values ("20123456A", "02");
insert into Matricula values ("54024103R", "01");

